進入主介面之後首先看到了doctor list,可以add doctor、delete doctor以及點選doctor name等這些button來進入doctor data介面。

使用者可以在doctor data 介面了解到doctor 姓名、性別、主治科目、上次登入時間以及病人列表，點選patient list 上的patient即可進入patient data 的頁面。

也可以點add patient ,delete patient 在patient list上進行刪除新增patient。

在patient data介面中，使用者可以得知到patient 的姓名,性別,疾病,病史以及備註Note。

在add patient 介面中，使用者可以利用此頁面來存入patient 的姓名,性別,疾病,病史以及備註Note。

在add doctor頁面中，使用者可以利用此頁面來存入doctor的姓名,性別以及主治科目。