# Setup
1. open command line and then enter the directory of the project
2. compile: write in command line <br />
`$ javac src/guess/number/SocketServer.java`<br />
`$ javac src/guess/number/SocketClient.java`<br />
3. run:<br/>
`$ java src/guess/number/SocketServer`<br />

    open new command line and enter the same directory <br />
    `$ java src/guess/number/SocketClient`<br />
4. start to play guess number
