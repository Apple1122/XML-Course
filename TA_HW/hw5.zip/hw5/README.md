# homework5
Open cmd and do the script

=====================

1. compile and build jar <br />
`$ant jar` <br />

2. execute server.sh & client.sh<br />
run server <br />
`$chmod +x server.sh` <br />
`$./server.sh` <br />
run client <br />
`$chmod +x client.sh` <br />
`./client.sh` <br />
