java -jar dist/Server.jar
