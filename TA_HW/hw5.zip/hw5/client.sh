java -jar dist/Client.jar
